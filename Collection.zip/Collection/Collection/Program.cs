﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int age { get; set; }

        //constructore
        /*
        public Student(int id, string n, int a)
        {
            Id = id;
            Name = n;
            age = a;
        }*/
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            //list of integers
            /*
            List<string> myList = new List<string>();
            for(int i = 0; i < 5; i++)
            {
                myList.Add($" {i.ToString()} Hello ");
            }
            //displaying items using foreach
            foreach (string item in myList)
                Console.WriteLine(item);
            */

            //Creatimg list of students with initial capacity 2
            List<Student> students = new List<Student>(2);

            //create objects of student class
            Student stu1 = new Student()
            {
                Id = 1,
                Name = "Rohit",
                age = 23
            };

            Student stu2 = new Student()
            {
                Id = 2,
                Name = "Mansi",
                age = 25
            };

            Student stu3 = new Student()
            {
                Id = 3,
                Name = "Savi",
                age = 34
            };

            var nameRandom = new Random();
            var ageRandom = new Random();

            students.Add(stu1);
            students.Add(stu2);
            //students.Add(new Student(101, "Hema", 22));
            //cap is only 2 but list grew dynamically
            students.Add(stu3);
            for (int i = 0; i < 4; i++)
            {
                students.Add(new Student()
                {
                    Id = i,
                    Name = nameRandom.Next(10, 1000).ToString(),
                    age = ageRandom.Next(10, 40)
                });
            }
            //count total number  of students
            Console.WriteLine(students.Count);//3
            //Console.WriteLine(students.Capacity);//4(by default starts with 0 den goes 4,8,16,32)

            //access using index
            //classname objname = listname[index]
            Student s1 = students[1];
            //Console.WriteLine($"Student Id : {s1.Id}, Name :  {s1.Name}, Age :  {s1.age}");

            //access all the items of list using foreach
            int minage = Int32.MaxValue;
            foreach (Student s in students)
            {
                if (minage > s.age)
                {
                    minage = s.age;
                }
                //Math.Min(minage, s.age);
                if (s.age > 30)
                {
                    List<Student> newList = new List<Student>();
                    Console.WriteLine($"Id : {s.Id}, Name: {s.Name}, age: {s.age}");
                }
                //Console.WriteLine(minage);

                var result = from student in students where student.age > 20 select student ;
                foreach (Student student in result)
                {
                    Console.Write(student.age+" ");
                }




            }
        }
    }
}
